from django import forms
from .models import Payment
from django import forms
from .models import Item  # Add this import at the top
class LoanForm(forms.Form):
    principal = forms.DecimalField(
        label="Principal Amount",
        min_value=0.01,
        max_digits=15,
        decimal_places=2,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter principal amount'})
    )
    interest_rate = forms.DecimalField(
        label="Interest Rate (%)",
        min_value=0,
        max_digits=5,
        decimal_places=2,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter interest rate'})
    )
    interest_mode = forms.ChoiceField(
        label="Interest Mode",
        choices=[('daily', 'Daily'), ('monthly', 'Monthly'), ('yearly', 'Yearly')],
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    start_date = forms.DateField(
        label="Start Date",
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
    )

# loan_app/forms.py
from django import forms
from .models import Payment

class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['date', 'amount']
        widgets = {
            'date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control',
                'required': 'required'
            }),
            'amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter amount',
                'required': 'required',
                'step': '0.01',
                'min': '0.01'
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['date'].label = "Payment Date"
        self.fields['amount'].label = "Payment Amount"

from django import forms
from .models import Client

class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['name', 'phone', 'shop_name', 'address']
        widgets = {
            'address': forms.Textarea(attrs={'rows': 3}),
        }

from .models import Borrow

# loan_app/forms.py
from django import forms
from .models import Borrow, Item

class BorrowForm(forms.ModelForm):
    class Meta:
        model = Borrow
        fields = ['date','interest_rate', 'interest_mode']  # Include both date and amount
        widgets = {
            'date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control',
                'required': 'required'
            }),
            
            'interest_rate': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Interest Rate',
                'step': '0.01',
                'min': '0'
            }),
            'interest_mode': forms.Select(attrs={
                'class': 'form-select'
            })
        
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['interest_rate'].label = "Interest Rate (%)"
        self.fields['interest_mode'].label = "Interest Mode"
        # No need to configure amount field anymore
        
    # Item fields
    item_name = forms.CharField(
        max_length=100,
        required=True,  # Changed to required
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'id': 'id_item_name'
        })
    )
    
    item_unit = forms.ChoiceField(
        choices=Item.UNIT_CHOICES,
        required=True,  # Changed to required
        widget=forms.Select(attrs={
            'class': 'form-select',
            'id': 'id_item_unit'
        })
    )
    
    item_quantity = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,  # Changed to required
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'id': 'id_item_quantity',
            'step': '0.01',
            'min': '0.01'
        })
    )
    
    price_per_unit = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,  # Changed to required
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'id': 'id_price_per_unit',
            'step': '0.01',
            'min': '0.01'
        })
    )
    
    receiver_name = forms.CharField(
        max_length=100,
        required=True,  # Changed to required
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'id': 'id_receiver_name'
        })
    )
    
    challan_number = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'id': 'id_challan_number',
            'placeholder': 'Enter challan number'
        })
    )

    
from django import forms
from .models import Item
class ItemForm(forms.Form):
    item_name = forms.CharField(max_length=100, required=False)
    item_unit = forms.ChoiceField(choices=Item.UNIT_CHOICES, required=False)
    item_quantity = forms.DecimalField(max_digits=10, decimal_places=2, required=False)



# Add to forms.py
class ItemForm(forms.Form):
    item_name = forms.CharField(
        max_length=100,
        required=True,   # 🔹 changed
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Item name'
        })
    )
    item_unit = forms.ChoiceField(
        choices=Item.UNIT_CHOICES,
        required=True,   # 🔹 changed
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    item_quantity = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,   # 🔹 changed
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Quantity',
            'step': '0.01',
            'min': '0.01'
        })
    )
    receiver_name = forms.CharField(
        max_length=100,
        required=True,   # 🔹 changed
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Receiver name'
        })
    )
    price_per_unit = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=True,   # 🔹 changed
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Price per unit',
            'step': '0.01',
            'min': '0.01'
        })
    )

    
from .models import ItemLog  
class ItemLogForm(forms.ModelForm):
    class Meta:
        model = ItemLog
        fields = ['date', 'item_name', 'delivered_to', 'expected_return_date', 'actual_return_date', 'cost']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'expected_return_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'actual_return_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'item_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Item name'}),
            'delivered_to': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Delivered to'}),
            'cost': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Cost', 'step': '0.01'}),
        }
        
        
class PaymentEditForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['date', 'amount']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}),
        }
        
class BorrowEditForm(forms.ModelForm):
    class Meta:
        model = Borrow
        fields = ['date', 'amount', 'interest_rate', 'interest_mode']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}),
            'interest_rate': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0'}),
            'interest_mode': forms.Select(attrs={'class': 'form-select'}),
        }
        
from django.core.exceptions import ValidationError

# Add to your forms.py
from .models import Casting
class CastingForm(forms.ModelForm):
    class Meta:
        model = Casting
        fields = ['item_name', 'caster_name', 'unit', 'narration', 'quantity', 'shot_charge']
        widgets = {
            'item_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter item name',
                'required': 'required'
            }),
            'caster_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter caster name',
                'required': 'required'
            }),
            'unit': forms.Select(attrs={
                'class': 'form-select',
                'required': 'required'
            }),
            'narration': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Enter narration',
                'rows': 3,
                'required': 'required'
            }),
            'quantity': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter quantity',
                'step': '0.01',
                'min': '0.01',
                'required': 'required'
            }),
            'shot_charge': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter shot charge',
                'step': '0.01',
                'min': '0.01',
                'required': 'required'
            }),
        }
        
    def __init__(self, *args, **kwargs):
        self.client = kwargs.pop('client', None)
        super().__init__(*args, **kwargs)

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if self.client and quantity:
            # Check if casting quantity exceeds remaining quantity
            remaining_quantity = self.client.remaining_quantity()
            if quantity > remaining_quantity:
                raise ValidationError(
                    f"Cannot cast {quantity} units. Only {remaining_quantity} units remaining."
                )
        return quantity
    

from django import forms
from .models import CastingKhata, CastingOrder

# ... existing forms ...

class CastingKhataForm(forms.ModelForm):
    class Meta:
        model = CastingKhata
        fields = ['caster_name', 'allocated_quantity']
        widgets = {
            'caster_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Caster name',
                'required': 'required'
            }),
            'allocated_quantity': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Quantity to allocate',
                'step': '0.01',
                'min': '0.01',
                'required': 'required'
            }),
        }

class CastingOrderForm(forms.ModelForm):
    class Meta:
        model = CastingOrder
        fields = ['order_quantity', 'notes']
        widgets = {
            'order_quantity': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Order quantity',
                'step': '0.01',
                'min': '0.01',
                'required': 'required'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Order notes (optional)',
                'rows': 2
            }),
        }
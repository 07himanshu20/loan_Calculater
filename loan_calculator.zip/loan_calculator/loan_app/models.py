from django.db import models
from django.db.models import Sum, F, ExpressionWrapper, DecimalField
from decimal import Decimal



class Client(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15, unique=True)
    shop_name = models.CharField(max_length=100)
    address = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def total_borrowed(self):
        total = Decimal('0')
        for loan in self.loans.all():
            total += loan.initial_principal
            total += loan.borrows.aggregate(total=Sum('amount'))['total'] or Decimal('0')
        return total
    
    def total_paid(self):
        # Sum of all payment amounts for this client
        total = Decimal('0')
        for loan in self.loans.all():
            total += loan.payments.aggregate(total=Sum('amount'))['total'] or Decimal('0')
        return total
    
    def current_balance(self):
        balance = Decimal('0')
        for loan in self.loans.all():
            balance += (loan.principal + loan.total_interest - loan.total_paid)
        return balance
    
    def total_interest(self):
        result = self.loans.aggregate(total=Sum('payments__interest_accrued'))['total']
        return result if result else Decimal('0.00')
    
    def total_quantity(self):
        """Calculate total quantity from all items across all loans"""
        total = Decimal('0.00')
        for loan in self.loans.all():
            for item in loan.items.all():
                if item.quantity:
                    total += item.quantity
        return total
    
    def remaining_quantity(self):
        """Calculate remaining quantity after deducting casting usage"""
        total_quantity = self.total_quantity()
        total_casted = self.castings.aggregate(total=Sum('quantity'))['total'] or Decimal('0.00')
        return total_quantity - total_casted
    
    def total_casted_quantity(self):
        """Calculate total quantity casted across all castings"""
        return self.castings.aggregate(total=Sum('quantity'))['total'] or Decimal('0.00')
    
    def remaining_quantity(self):
        """Calculate remaining quantity after deducting casting usage"""
        total_quantity = self.total_quantity()
        total_casted = self.total_casted_quantity()
        return total_quantity - total_casted

    
    

class Loan(models.Model):
    INTEREST_MODES = [
        ('daily', 'Daily'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ]
    
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='loans')
    principal = models.DecimalField(max_digits=15, decimal_places=2)
    initial_principal = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2)
    interest_mode = models.CharField(max_length=10, choices=INTEREST_MODES)
    start_date = models.DateField()
    total_interest = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    current_balance = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    current_principal = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    current_interest = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_paid = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    profit = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        if not self.pk:  # Only set initial_principal when first created
            self.initial_principal = self.principal
            self.current_principal = self.principal
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"₹{self.initial_principal} loan to {self.client.name}"

class Borrow(models.Model):
    loan = models.ForeignKey(Loan, on_delete=models.CASCADE, related_name='borrows')
    date = models.DateField()
    amount = models.DecimalField(max_digits=10, decimal_places=2,blank=True, null=True)
    # Add these new fields
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    interest_mode = models.CharField(max_length=10, choices=Loan.INTEREST_MODES, default='daily')
    
    days_since_last = models.IntegerField(default=0)
    interest_accrued = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    balance_before = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    balance_after = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    def __str__(self):
        return f"₹{self.amount} on {self.date}"
    
    
class Item(models.Model):
    @property
    def total_value(self):
        if self.price_per_unit and self.quantity:
            return self.price_per_unit * self.quantity
        return Decimal('0')
    
    UNIT_CHOICES = [
        ('kg', 'Kilogram'),
        ('g', 'Gram'),
        ('l', 'Liter'),
        ('ml', 'Milliliter'),
        ('piece', 'Piece'),
        ('packet', 'Packet'),
    ]
    
    loan = models.ForeignKey(Loan, on_delete=models.CASCADE, related_name='items')
    borrow = models.ForeignKey(Borrow, on_delete=models.SET_NULL, null=True, blank=True)  
    name = models.CharField(max_length=100)
    unit = models.CharField(max_length=10, choices=UNIT_CHOICES)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    receiver_name = models.CharField(max_length=100, blank=True, null=True)
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    challan_number = models.CharField(max_length=20) # New field
    status = models.CharField(max_length=20, default="Pending")  # 🔹 New field
    created_at = models.DateTimeField(auto_now_add=True)

    def total_value(self):
        if self.price_per_unit is not None and self.quantity is not None:
            return self.price_per_unit * self.quantity
        return Decimal('0')
    
    def get_display_date(self):
        return self.borrow.date if self.borrow else self.loan.start_date
    
    def __str__(self):
        return f"{self.quantity} {self.get_unit_display()} of {self.name}"

class Payment(models.Model):
    loan = models.ForeignKey(Loan, on_delete=models.CASCADE, related_name='payments')
    date = models.DateField()
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    days_since_last = models.IntegerField(default=0)
    interest_accrued = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    interest_paid = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    principal_paid = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    balance_without_interest = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    balance_with_interest = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"₹{self.amount} on {self.date}"
    

    
class ItemLog(models.Model):
    date = models.DateField()
    item_name = models.CharField(max_length=100)
    delivered_to = models.CharField(max_length=100)
    expected_return_date = models.DateField()
    actual_return_date = models.DateField(null=True, blank=True)
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.item_name} to {self.delivered_to}"
    
# Add to models.py

# Add to your models.py
class Casting(models.Model):
    UNIT_CHOICES = [
        ('kg', 'Kilogram'),
        ('g', 'Gram'),
        ('piece', 'Piece'),
        ('packet', 'Packet'),
    ]
    
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='castings')
    item_name = models.CharField(max_length=100)
    caster_name = models.CharField(max_length=100)
    unit = models.CharField(max_length=10, choices=UNIT_CHOICES)
    narration = models.TextField()
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    shot_charge = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.item_name} - {self.caster_name}"
    
    def total_amount(self):
        return self.quantity * self.shot_charge
    
class CastingKhata(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='casting_khatas')
    caster_name = models.CharField(max_length=100)
    allocated_quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    available_quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.caster_name} - {self.available_quantity} kg"
    
    def calculate_expected_return(self, order_quantity):
        """
        Calculate expected return quantity using the formula:
        (allocated_quantity * order_quantity) / ((5% of allocated_quantity) + allocated_quantity)
        """
        five_percent = self.allocated_quantity * Decimal('0.05')
        denominator = five_percent + self.allocated_quantity
        if denominator == 0:
            return Decimal('0')
        return (self.allocated_quantity * order_quantity) / denominator
    
    def get_status(self):
        """Calculate status based on sum of all balances"""
        total_balance = self.orders.aggregate(
            total_balance=Sum(F('expected_return') - F('actual_return'))
        )['total_balance'] or Decimal('0.00')
        
        # Consider balances close to zero as clear (within 0.01 kg tolerance)
        if abs(total_balance) < Decimal('0.01'):
            return "Clear"
        else:
            return f"Balance: {total_balance:.2f} kg"

class CastingOrder(models.Model):
    casting_khata = models.ForeignKey(CastingKhata, on_delete=models.CASCADE, related_name='orders')
    order_quantity = models.DecimalField(max_digits=10, decimal_places=2)
    expected_return = models.DecimalField(max_digits=10, decimal_places=2)
    actual_return = models.DecimalField(max_digits=10, decimal_places=2, default=0, null=True, blank=True)
    
    order_date = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"Order: {self.order_quantity} kg (Expected: {self.expected_return} kg)"
    
    def get_balance(self):
        """Calculate balance for this order"""
        if self.actual_return is None:
            return self.expected_return
        return self.expected_return - self.actual_return
from django.urls import path
from .views import AddPaymentView
from . import views
from .views import ClientDeleteView
from .views import AddBorrowView
from django.urls import path
from .views import ItemLogView, delete_item_log
from .views import CastingListView, CastingDeleteView
from .views import AddCastingQuantityView, CreateCastingOrderView, GetCastingOrdersView,DeleteCastingKhataView, UpdateActualReturnView
from .views import CastingEditView


from .views import CalculatorView
from .views import DashboardView, ClientCreateView, save_logs, open_khata
from .views import (
    DashboardView, 
    ClientCreateView, 
    CalculatorView,
    ClientDetailView,
    AddPaymentView
)


urlpatterns = [
    path('', DashboardView.as_view(), name='dashboard'),
    path('client/add/', ClientCreateView.as_view(), name='add_client'),
    path('save-logs/', save_logs, name='save_logs'),
    path('open-khata/<int:client_id>/', open_khata, name='open_khata'),
    path('calculator/', CalculatorView.as_view(), name='calculator'),
    path('client/<int:pk>/add-payment/', AddPaymentView.as_view(), name='add_payment'),
    path('', DashboardView.as_view(), name='dashboard'),
    path('client/<int:pk>/add-borrow/', AddBorrowView.as_view(), name='add_borrow'),
    path('client/add/', ClientCreateView.as_view(), name='add_client'),
    path('client/<int:pk>/', ClientDetailView.as_view(), name='client_detail'),
    path('client/<int:pk>/add-payment/', AddPaymentView.as_view(), name='add_payment'),
    path('calculator/', CalculatorView.as_view(), name='calculator'),
    path('save-logs/', save_logs, name='save_logs'),
    path('debug-loans/', views.debug_loans, name='debug_loans'),
    path('client/<int:pk>/delete/', ClientDeleteView.as_view(), name='client_delete'),
    path('item-logs/', ItemLogView.as_view(), name='item_logs'),
    path('delete-item-log/<int:pk>/', delete_item_log, name='delete_item_log'),
    
    path('payment/<int:pk>/edit/', views.PaymentEditView.as_view(), name='edit_payment'),
    path('payment/<int:pk>/delete/', views.PaymentDeleteView.as_view(), name='delete_payment'),
    path('borrow/<int:pk>/edit/', views.BorrowEditView.as_view(), name='edit_borrow'),
    path('borrow/<int:pk>/delete/', views.BorrowDeleteView.as_view(), name='delete_borrow'),
    
    path('client/<int:client_id>/casting/', CastingListView.as_view(), name='casting_list'),
    path('casting/delete/<int:pk>/', CastingDeleteView.as_view(), name='casting_delete'),
    
    path('casting-khata/<int:khata_id>/add-quantity/', AddCastingQuantityView.as_view(), name='add_casting_quantity'),
    path('casting-khata/<int:khata_id>/create-order/', CreateCastingOrderView.as_view(), name='create_casting_order'),
    path('casting-khata/<int:khata_id>/orders/', GetCastingOrdersView.as_view(), name='get_casting_orders'),
    path('casting-khata/<int:khata_id>/delete/', DeleteCastingKhataView.as_view(), name='delete_casting_khata'),
    path('casting-order/<int:order_id>/update-actual-return/', UpdateActualReturnView.as_view(), name='update_actual_return'),
    path('casting/edit/<int:pk>/', CastingEditView.as_view(), name='casting_edit'),
    
]
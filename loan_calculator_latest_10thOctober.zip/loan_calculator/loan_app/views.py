from django.shortcuts import render, redirect
from django.views import View
from datetime import date, datetime
from decimal import Decimal
from .forms import LoanForm
from django.contrib import messages
from .forms import LoanForm, PaymentForm, ClientForm, BorrowForm, ItemForm, ItemLogForm, PaymentEditForm, BorrowEditForm
from django.template.defaulttags import register
from django.views.generic import ListView, CreateView, DetailView
from .models import Client
from .forms import ClientForm
import csv
from django.http import HttpResponse
from datetime import datetime
from django.views.generic import ListView, CreateView, DetailView, UpdateView
from .models import Client, Loan, Payment
from .forms import ClientForm, PaymentForm
from django.urls import reverse

# Add to existing imports
from django.shortcuts import get_object_or_404
from django.urls import reverse
from .models import Borrow
from .forms import BorrowForm
from decimal import Decimal, InvalidOperation

class AddBorrowView(CreateView):
    model = Borrow
    form_class = BorrowForm
    template_name = 'loan_app/add_borrow.html'
    
    def form_valid(self, form):
        client_id = self.kwargs['pk']
        client = get_object_or_404(Client, id=client_id)
        loan = Loan.objects.filter(client=client).order_by('-created_at').first()
        
        if not loan:
            messages.error(self.request, "No loan found for this client")
            return redirect('client_detail', pk=client_id)

        # Get item data from POST
        item_name = self.request.POST.get('item_name')
        receiver_name = self.request.POST.get('receiver_name')
        unit = self.request.POST.get('item_unit')
        quantity = self.request.POST.get('item_quantity')
        price = self.request.POST.get('price_per_unit')
        challan_number = self.request.POST.get('challan_number')  # Get challan number from form

        try:
            amount = (Decimal(quantity) * Decimal(price)).quantize(Decimal('0.01'))
        except (InvalidOperation, TypeError):
            amount = Decimal('0')
            messages.error(self.request, "Invalid quantity or price value")
            return self.form_invalid(form)
        
        # Create the borrow record first
        borrow = form.save(commit=False)
        borrow.loan = loan
        borrow.amount = amount  # Set the calculated amount
        with transaction.atomic():
            borrow.save()

            if item_name and receiver_name and unit and quantity and price and challan_number:
                try:
                    if Item.objects.filter(loan=loan, challan_number=challan_number).exists():
                        messages.error(self.request, f"Challan number {challan_number} already exists for this loan")
                        return self.form_invalid(form)
                    
                    item = Item.objects.create(
                        loan=loan,
                        borrow=borrow,
                        name=item_name,
                        receiver_name=receiver_name,
                        unit=unit,
                        quantity=Decimal(quantity).quantize(Decimal('0.01')),
                        price_per_unit=Decimal(price).quantize(Decimal('0.01')),
                        challan_number=challan_number,
                        status="Pending"
                    )
                    
                    item_value = item.total_value()
                    if item_value:
                        loan.principal += item_value
                        loan.current_principal += item_value
                        loan.save()
                    
                    messages.success(self.request, f"Borrow and item added successfully with challan #{challan_number}!")
                except Exception as e:
                    messages.error(self.request, f"Error creating item: {str(e)}")
            else:
                messages.success(self.request, "Borrow added successfully (no item recorded)")

        return redirect('client_detail', pk=client_id)

    def calculate_interest(self, principal, rate, days, mode):
        principal = Decimal(str(principal))
        rate = Decimal(str(rate))
        days = Decimal(str(days))
        
        if principal <= Decimal('0'):
            return Decimal('0')
            
        if mode == 'daily':
            return principal * ((rate / Decimal('365')) / Decimal('100')) * days
        elif mode == 'monthly':
            return principal * ((rate / Decimal('12')) / Decimal('100')) * days
        elif mode == 'yearly':
            return principal * ((rate / Decimal('1')) / Decimal('100')) * days
        return Decimal('0')
    
    def get_success_url(self):
        client_id = self.kwargs.get('pk')
        return reverse('client_detail', kwargs={'pk': client_id}) if client_id else reverse('dashboard')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        client_id = self.kwargs.get('pk')
        context['client'] = get_object_or_404(Client, id=client_id)
        return context


class DashboardView(ListView):
    model = Client
    template_name = 'loan_app/dashboard.html'
    context_object_name = 'clients'
    
    def get_queryset(self):
        # Prefetch related data for efficiency
        clients = Client.objects.prefetch_related(
            'loans',
            'loans__payments',
            'loans__borrows'
        ).all()
        
        # Use the exact same calculation logic as ClientDetailView
        for client in clients:
            # Calculate balance using the same method as ClientDetailView
            client.display_current_balance = self.calculate_client_balance(client)
            
            # Calculate total borrowed and total paid (consistent with ClientDetailView)
            total_borrowed = Decimal('0.00')
            total_paid = Decimal('0.00')
            
            for loan in client.loans.all():
                total_borrowed += loan.initial_principal
                for borrow in loan.borrows.all():
                    if borrow.amount:
                        total_borrowed += borrow.amount
                for payment in loan.payments.all():
                    if payment.amount:
                        total_paid += payment.amount
            
            client.display_total_borrowed = total_borrowed
            client.display_total_paid = total_paid
        
        return clients
    
    def calculate_client_balance(self, client):
        """Exact same calculation as ClientDetailView - FIXED VERSION"""
        loans = Loan.objects.filter(client=client).prefetch_related('payments', 'borrows')
        
        total_balance = Decimal('0.00')
        
        for loan in loans:
            # Group transactions by their interest rate and mode
            transactions = []
            
            # Add initial loan as a transaction
            transactions.append(('loan', loan.start_date, loan.initial_principal, 
                            loan.interest_rate, loan.interest_mode, None))
            
            # Add borrows with their specific interest rates
            for borrow in loan.borrows.all().order_by('date'):
                transactions.append(('borrow', borrow.date, borrow.amount, 
                                borrow.interest_rate, borrow.interest_mode, borrow))
            
            # Add payments
            for payment in loan.payments.all().order_by('date'):
                transactions.append(('payment', payment.date, -payment.amount, 
                                None, None, payment))
            
            # Sort all transactions by date
            transactions.sort(key=lambda x: x[1])
            
            # FIXED: Use running principal instead of complex principal groups
            current_date = loan.start_date
            running_principal = loan.initial_principal
            running_balance_with_interest = loan.initial_principal
            
            for trans_type, trans_date, amount, rate, mode, obj in transactions:
                days = (trans_date - current_date).days
                if days < 0:
                    continue
                
                # FIXED: Calculate interest based on running principal
                daily_interest = self.calculate_interest(running_principal, loan.interest_rate, days, loan.interest_mode)
                running_balance_with_interest += daily_interest
                
                if trans_type == 'borrow':
                    # Add borrow amount to running principal
                    running_principal += amount
                    running_balance_with_interest += amount
                    
                elif trans_type == 'payment':
                    # Subtract payment from running principal
                    running_principal += amount  # amount is negative for payments
                    running_balance_with_interest += amount
                
                current_date = trans_date
            
            # Calculate final interest from last transaction to today
            final_days = (date.today() - current_date).days
            if final_days > 0 and running_principal > 0:
                final_interest = self.calculate_interest(running_principal, loan.interest_rate, final_days, loan.interest_mode)
            else:
                final_interest = Decimal('0.00')
            
            # Final balance calculation (SAME as ClientDetailView)
            loan_current_balance = (running_balance_with_interest + final_interest).quantize(Decimal('0.01'))
            total_balance += loan_current_balance
        
        return total_balance
    
    def calculate_interest(self, principal, rate, days, mode):
        principal = Decimal(str(principal))
        rate = Decimal(str(rate))
        days = Decimal(str(days))
        
        if principal <= Decimal('0'):
            return Decimal('0')
            
        if mode == 'daily':
            return principal * ((rate / Decimal('365')) / Decimal('100')) * days
        elif mode == 'monthly':
            return principal * ((rate / Decimal('12')) / Decimal('100')) * days
        elif mode == 'yearly':
            return principal * ((rate / Decimal('1')) / Decimal('100')) * days
        return Decimal('0')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['client_form'] = ClientForm()
        return context    
    
from django.views.generic import DeleteView
from django.urls import reverse_lazy

class ClientDeleteView(DeleteView):
    model = Client
    template_name = 'loan_app/client_confirm_delete.html'
    success_url = reverse_lazy('dashboard')
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, "Client and all related records deleted successfully.")
        return super().delete(request, *args, **kwargs)

class ClientDetailView(DetailView):
    model = Client
    template_name = 'loan_app/client_detail.html'
    context_object_name = 'client'
    
    def calculate_interest(self, principal, rate, days, mode):
        principal = Decimal(str(principal))
        rate = Decimal(str(rate))
        days = Decimal(str(days))
        
        if principal <= Decimal('0'):
            return Decimal('0')
            
        if mode == 'daily':
            return principal * ((rate / Decimal('365')) / Decimal('100')) * days
        elif mode == 'monthly':
            return principal * ((rate / Decimal('12')) / Decimal('100')) * days
        elif mode == 'yearly':
            return principal * ((rate / Decimal('1')) / Decimal('100')) * days
        return Decimal('0')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        client = self.object
        loans = Loan.objects.filter(client=client).prefetch_related('payments', 'borrows')
        
        loan_summaries = []
        total_borrowed = Decimal('0.00')
        total_paid = Decimal('0.00')
        total_interest = Decimal('0.00')
        current_balance = Decimal('0.00')
        
        for loan in loans:
            # Group transactions by their interest rate and mode
            total_borrowed += loan.initial_principal
            transactions = []
            
            # Add initial loan as a transaction
            transactions.append(('loan', loan.start_date, loan.initial_principal, 
                            loan.interest_rate, loan.interest_mode, None))
            
            # Add borrows with their specific interest rates
            for borrow in loan.borrows.all().order_by('date'):
                transactions.append(('borrow', borrow.date, borrow.amount, 
                                borrow.interest_rate, borrow.interest_mode, borrow))
                total_borrowed += borrow.amount  # Add borrow amount to total borrowed
            
            # Add payments
            for payment in loan.payments.all().order_by('date'):
                transactions.append(('payment', payment.date, -payment.amount, 
                                None, None, payment))
                total_paid += payment.amount  # Add payment amount to total paid
            
            # Sort all transactions by date
            transactions.sort(key=lambda x: x[1])
            
            # Calculate timeline with different interest rates for different principals
            timeline = []
            current_date = loan.start_date
            
            # FIXED: Track running principal balance for interest calculation
            running_principal = loan.initial_principal  # This will track the actual principal balance
            running_balance_with_interest = loan.initial_principal
            
            for trans_type, trans_date, amount, rate, mode, obj in transactions:
                days = (trans_date - current_date).days
                if days < 0:
                    continue
                
                # FIXED: Calculate interest based on running principal, not initial principal
                daily_interest = self.calculate_interest(running_principal, loan.interest_rate, days, loan.interest_mode)
                running_balance_with_interest += daily_interest
                
                if trans_type == 'borrow':
                    # Add borrow amount to running principal
                    running_principal += amount
                    running_balance_with_interest += amount
                    
                    timeline.append({
                        'type': 'borrow',
                        'date': trans_date.strftime('%b. %d, %Y'),
                        'days': days,
                        'interest': float(daily_interest), 
                        'amount': float(amount),
                        'obj': obj,
                        'interest_rate': rate,
                        'interest_mode': mode,
                        'balance_without_interest': float(running_principal),  # FIXED: Use running_principal
                        'balance_with_interest': float(running_balance_with_interest)
                    })
                
                elif trans_type == 'payment':
                    # FIXED: Subtract payment from running principal
                    running_principal += amount  # amount is negative for payments
                    running_balance_with_interest += amount
                    
                    timeline.append({
                        'type': 'payment',
                        'date': trans_date.strftime('%b. %d, %Y'),
                        'days': days,
                        'interest': float(daily_interest),
                        'amount': float(amount),
                        'obj': obj,
                        'balance_without_interest': float(running_principal),  # FIXED: Use running_principal
                        'balance_with_interest': float(running_balance_with_interest)
                    })
                
                current_date = trans_date
            
            # Calculate final interest from last transaction to today
            final_days = (date.today() - current_date).days
            if final_days > 0 and running_principal > 0:
                final_interest = self.calculate_interest(running_principal, loan.interest_rate, final_days, loan.interest_mode)
            else:
                final_interest = Decimal('0.00')
            
            total_interest += final_interest
            
            # Final balance calculation
            loan_current_balance = (running_balance_with_interest + final_interest).quantize(Decimal('0.01'))
            current_balance += loan_current_balance
            
            loan_summaries.append({
                'loan': loan,
                'timeline': timeline,
                'current_principal': running_principal,  # FIXED: Use the actual running principal
                'current_interest': final_interest,
                'current_balance': loan_current_balance,
            })

        # Process Items
        items = Item.objects.filter(loan__client=client).order_by('challan_number')
        total_paid_amount = total_paid
        
        for item in items:
            if total_paid_amount <= 0:
                break
                
            item_value = item.total_value() or Decimal('0.00')
            if total_paid_amount >= item_value:
                item.status = "Paid"
                total_paid_amount -= item_value
            else:
                break
            item.save()
        
        context['total_quantity'] = client.total_quantity()
        context['remaining_quantity'] = client.remaining_quantity()
        context['items'] = items
        context['total_borrowed'] = total_borrowed.quantize(Decimal('0.01'))
        context['total_paid'] = total_paid.quantize(Decimal('0.01'))
        context['total_interest'] = total_interest.quantize(Decimal('0.01'))
        context['current_balance'] = current_balance.quantize(Decimal('0.01'))
        context['loan_summaries'] = loan_summaries
        return context

from django.db.models import Sum
from django.db import transaction
from django.views.generic.edit import CreateView
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.utils.timezone import now
from decimal import Decimal
from datetime import date

class AddPaymentView(CreateView):
    model = Payment
    form_class = PaymentForm
    template_name = 'loan_app/add_payment.html'
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        if 'instance' in kwargs:
            del kwargs['instance']
        return kwargs
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        client_id = self.kwargs['pk']
        client = get_object_or_404(Client, id=client_id)
        
        # Use the exact same calculation method as ClientDetailView
        current_balance = self.calculate_client_balance(client)
        
        context['client'] = client 
        context['current_balance'] = current_balance
            
        return context
    
    
    def calculate_client_balance(self, client):
        """Exact same calculation as ClientDetailView - FIXED VERSION"""
        loans = Loan.objects.filter(client=client).prefetch_related('payments', 'borrows')
        
        total_balance = Decimal('0.00')
        
        for loan in loans:
            # Group transactions by their interest rate and mode
            transactions = []
            
            # Add initial loan as a transaction
            transactions.append(('loan', loan.start_date, loan.initial_principal, 
                            loan.interest_rate, loan.interest_mode, None))
            
            # Add borrows with their specific interest rates
            for borrow in loan.borrows.all().order_by('date'):
                transactions.append(('borrow', borrow.date, borrow.amount, 
                                borrow.interest_rate, borrow.interest_mode, borrow))
            
            # Add payments
            for payment in loan.payments.all().order_by('date'):
                transactions.append(('payment', payment.date, -payment.amount, 
                                None, None, payment))
            
            # Sort all transactions by date
            transactions.sort(key=lambda x: x[1])
            
            # FIXED: Use running principal instead of complex principal groups
            current_date = loan.start_date
            running_principal = loan.initial_principal
            running_balance_with_interest = loan.initial_principal
            
            for trans_type, trans_date, amount, rate, mode, obj in transactions:
                days = (trans_date - current_date).days
                if days < 0:
                    continue
                
                # FIXED: Calculate interest based on running principal
                daily_interest = self.calculate_interest(running_principal, loan.interest_rate, days, loan.interest_mode)
                running_balance_with_interest += daily_interest
                
                if trans_type == 'borrow':
                    # Add borrow amount to running principal
                    running_principal += amount
                    running_balance_with_interest += amount
                    
                elif trans_type == 'payment':
                    # Subtract payment from running principal
                    running_principal += amount  # amount is negative for payments
                    running_balance_with_interest += amount
                
                current_date = trans_date
            
            # Calculate final interest from last transaction to today
            final_days = (date.today() - current_date).days
            if final_days > 0 and running_principal > 0:
                final_interest = self.calculate_interest(running_principal, loan.interest_rate, final_days, loan.interest_mode)
            else:
                final_interest = Decimal('0.00')
            
            # Final balance calculation
            loan_current_balance = (running_balance_with_interest + final_interest).quantize(Decimal('0.01'))
            total_balance += loan_current_balance
        
        return total_balance
        
    
    def form_valid(self, form):
        client_id = self.kwargs['pk']
        client = get_object_or_404(Client, id=client_id)
        
        # Get the specific loan to apply payment to
        loan = Loan.objects.filter(client=client).order_by('-created_at').first()

        if not loan:
            messages.error(self.request, "No loan found for this client")
            return redirect('client_detail', pk=client_id)
        
        payment_date = form.cleaned_data['date']
        payment_amount = Decimal(str(form.cleaned_data['amount']))
        
        # Use the SAME calculation method as get_context_data() for validation
        current_balance = self.calculate_client_balance(client)
        
        if payment_amount > current_balance:
            messages.error(self.request, f"Payment amount cannot exceed current balance of ₹{current_balance}")
            return self.form_invalid(form)
        
        if payment_date < loan.start_date:
            messages.error(self.request, f"Payment date cannot be before loan start date ({loan.start_date})")
            return self.form_invalid(form)

        # Get last transaction date
        last_payment = loan.payments.order_by('-date').first()
        last_borrow = loan.borrows.order_by('-date').first()
        last_date = loan.start_date
        if last_payment and last_payment.date > last_date:
            last_date = last_payment.date
        if last_borrow and last_borrow.date > last_date:
            last_date = last_borrow.date
            
        days = (payment_date - last_date).days
        if days < 0:
            messages.error(self.request, "Payment date cannot be before last transaction")
            return self.form_invalid(form)
            
        # Calculate interest for all principal groups
        interest = Decimal('0.00')
        principal_groups = self.get_principal_groups(loan)
        
        for group in principal_groups:
            group_interest = self.calculate_interest(
                group['principal'], group['rate'], days, group['mode']
            )
            interest += group_interest
        
        # Apply payment to oldest unpaid challans first
        remaining_payment = payment_amount
        unpaid_items = Item.objects.filter(loan=loan, status="Pending").order_by('challan_number')
        
        for item in unpaid_items:
            if remaining_payment <= 0:
                break
            
            item_value = item.total_value() or Decimal('0')
            
            if remaining_payment >= item_value:
                item.status = "Paid"
                remaining_payment -= item_value
                item.save()
            else:
                remaining_payment = Decimal('0')
            item.save()

        # Create payment
        payment = form.save(commit=False)
        payment.loan = loan
        payment.days_since_last = days
        payment.interest_accrued = interest
        payment.interest_paid = Decimal('0.00')
        payment.principal_paid = payment_amount
        
        # Update loan balances
        loan.principal -= payment_amount
        loan.total_interest += interest
        loan.total_paid += payment_amount
        loan.current_balance = loan.principal + loan.total_interest - loan.total_paid
        
        payment.balance_without_interest = loan.principal
        payment.balance_with_interest = loan.current_balance
        
        with transaction.atomic():
            payment.save()
            loan.save()
        
        messages.success(self.request, "Payment added successfully!")
        return super().form_valid(form)
    
    def get_principal_groups(self, loan):
        groups = []
        
        # Add initial loan
        groups.append({
            'principal': loan.initial_principal,
            'rate': loan.interest_rate,
            'mode': loan.interest_mode
        })
        
        # Add borrows
        for borrow in loan.borrows.all():
            groups.append({
                'principal': borrow.amount,
                'rate': borrow.interest_rate,
                'mode': borrow.interest_mode
            })
        
        return groups
    
    def calculate_interest(self, principal, rate, days, mode):
        principal = Decimal(str(principal))
        rate = Decimal(str(rate))
        days = Decimal(str(days))
        
        if principal <= Decimal('0'):
            return Decimal('0')
            
        if mode == 'daily':
            return principal * ((rate / Decimal('365')) / Decimal('100')) * days
        elif mode == 'monthly':
            return principal * ((rate / Decimal('12')) / Decimal('100')) * days
        elif mode == 'yearly':
            return principal * ((rate / Decimal('1')) / Decimal('100')) * days
        return Decimal('0')
        
    def get_success_url(self):
        client_id = self.kwargs['pk']
        return reverse('client_detail', kwargs={'pk': client_id})
    
    
class ClientCreateView(CreateView):
    model = Client
    form_class = ClientForm
    template_name = 'loan_app/client_form.html'
    
    def get_success_url(self):
        # Store client ID in session for calculator
        self.request.session['current_client_id'] = self.object.id
        return reverse('calculator')
        
    def form_valid(self, form):
        # Clear previous client session
        self.request.session.pop('current_client_id', None)
        return super().form_valid(form)

@register.filter
def div(value, arg):
    try:
        return float(value) / float(arg)
    except (ValueError, ZeroDivisionError):
        return 0

from .models import Item  #
from .forms import ItemForm  # Add this import with your other form imports

class CalculatorView(View):
    template_name = 'loan_app/calculator.html'
    
    def get(self, request):
        # Clear session data on new page load
        request.session.pop('payments', None)
        request.session.pop('loan_data', None)
        request.session.pop('items', None)  # Clear items session
        
        loan_form = LoanForm()
        item_form = ItemForm() 
        
        current_client = None
        client_id = request.session.get('current_client_id')
        if client_id:
            try:
                current_client = Client.objects.get(id=client_id)
                # Update session with client info for base.html
                request.session['current_client'] = {
                    'name': current_client.name,
                    'shop_name': current_client.shop_name
                }
            except Client.DoesNotExist:
                # Clear invalid client reference
                request.session.pop('current_client_id', None)
                request.session.pop('current_client', None)
                messages.warning(request, "Client record not found!")
        else:
            # Clear any existing client session
            request.session.pop('current_client', None)
        
        return render(request, self.template_name, {
            'loan_form': loan_form,
            'payments': [],
            'current_client': current_client,
            'item_form': item_form 
        })
    
    def post(self, request):
        # Initialize forms with POST data
        loan_form = LoanForm(request.POST)
        item_form = ItemForm(request.POST)
        
        # Load data from session
        loan_data = request.session.get('loan_data', {})
        payments = request.session.get('payments', [])
        borrows = request.session.get('borrows', [])
        items = request.session.get('items', [])

        # --- Handle Add Payment ---
        if 'add_payment' in request.POST:
            date_val = request.POST.get('date')
            amount_val = request.POST.get('amount')
            
            if date_val and amount_val:
                try:
                    datetime.strptime(date_val, '%Y-%m-%d')
                    float(amount_val)

                    payments.append({
                        'date': date_val,
                        'amount': amount_val
                    })
                    request.session['payments'] = payments
                    messages.success(request, "Payment added successfully!")

                    if loan_form.is_valid():
                        loan_data = {
                            'principal': float(loan_form.cleaned_data['principal']),
                            'interest_rate': float(loan_form.cleaned_data['interest_rate']),
                            'interest_mode': loan_form.cleaned_data['interest_mode'],
                            'start_date': loan_form.cleaned_data['start_date'].isoformat(),
                        }
                        request.session['loan_data'] = loan_data

                except ValueError:
                    messages.error(request, "Invalid payment data")
            else:
                messages.error(request, "Please fill both date and amount fields")

        # --- Handle Remove Payment ---
        elif 'remove_payment' in request.POST:
            index = int(request.POST.get('remove_payment'))
            if 0 <= index < len(payments):
                del payments[index]
                request.session['payments'] = payments
                messages.info(request, "Payment removed successfully!")

        # --- Handle Add Borrow ---
        elif 'add_borrow' in request.POST:
            date_val = request.POST.get('borrow_date')
            amount_val = request.POST.get('borrow_amount')
            rate_val = request.POST.get('borrow_rate')
            mode_val = request.POST.get('borrow_mode')

            if date_val and amount_val and rate_val and mode_val:
                try:
                    datetime.strptime(date_val, '%Y-%m-%d')
                    float(amount_val)
                    float(rate_val)


                    borrows.append({
                        'date': date_val,
                        'amount': amount_val,
                        'rate': rate_val,
                        'mode': mode_val
                    })
                    request.session['borrows'] = borrows
                    messages.success(request, "Borrow added successfully!")

                except ValueError:
                    messages.error(request, "Invalid borrow data")
            else:
                messages.error(request, "Please fill both date and amount fields")

        # --- Handle Remove Borrow ---
        elif 'remove_borrow' in request.POST:
            index = int(request.POST.get('remove_borrow'))
            if 0 <= index < len(borrows):
                del borrows[index]
                request.session['borrows'] = borrows
                messages.info(request, "Borrow removed successfully!")

        # --- Handle Add Item ---
        elif 'add_item' in request.POST:
            if item_form.is_valid() and item_form.cleaned_data['item_name']:
                items.append({
                    'name': item_form.cleaned_data['item_name'],
                    'unit': item_form.cleaned_data['item_unit'],
                    'quantity': str(item_form.cleaned_data['item_quantity']),
                    'challan_number': item_form.cleaned_data['challan_number']  # Add challan nu
                })
                request.session['items'] = items
                messages.success(request, "Item added successfully!")
                item_form = ItemForm()  # Reset the form
            else:
                messages.error(request, "Please provide valid item details")

        # --- Handle Remove Item ---
        elif 'remove_item' in request.POST:
            index = int(request.POST.get('remove_item'))
            if 0 <= index < len(items):
                del items[index]
                request.session['items'] = items
                messages.info(request, "Item removed successfully!")

        # --- Handle Calculate ---
        elif 'calculate' in request.POST:
            if loan_form.is_valid():
                # Process complete item data
                item_data = {
                    'name': request.POST.get('item_name'),
                    'receiver_name': request.POST.get('receiver_name'),
                    'unit': request.POST.get('item_unit'),
                    'quantity': request.POST.get('item_quantity'),
                    'price_per_unit': request.POST.get('price_per_unit'),
                    'challan_number': request.POST.get('challan_number'),
                }

                # Validate all item fields are present
                if not all(item_data.values()):
                    messages.error(request, "Please fill all item details")
                    return self.render_form(request, loan_form, item_form, payments, borrows)

                # Save to database if client exists
                
                principal_amount = (Decimal(item_data['quantity']) * Decimal(item_data['price_per_unit'])).quantize(Decimal('0.01'))
                
                client_id = request.session.get('current_client_id')
                if client_id:
                    try:
                        client = Client.objects.get(id=client_id)
                        loan = Loan.objects.create(
                            client=client,
                            principal=Decimal(item_data['quantity']) * Decimal(item_data['price_per_unit']),
                            interest_rate=loan_form.cleaned_data['interest_rate'],
                            interest_mode=loan_form.cleaned_data['interest_mode'],
                            start_date=loan_form.cleaned_data['start_date'],
                            total_interest=Decimal('0'),
                            current_balance=Decimal(item_data['quantity']) * Decimal(item_data['price_per_unit']),
                            total_paid=Decimal('0'),
                            profit=Decimal('0')
                        )

                        # Create only one Item record (prevent duplicates)
                        Item.objects.create(
                            loan=loan,
                            name=item_data['name'],
                            receiver_name=item_data['receiver_name'],
                            unit=item_data['unit'],
                            quantity=Decimal(item_data['quantity']),
                            price_per_unit=Decimal(item_data['price_per_unit']).quantize(Decimal('0.01')),
                            challan_number=item_data['challan_number'],
                            status="Pending"
                        )

                    except Exception as e:
                        messages.error(request, f"Database error: {str(e)}")

                # Clear all session data
                request.session.pop('loan_data', None)
                request.session.pop('payments', None)
                request.session.pop('borrows', None)
                request.session.pop('items', None)

                return self.calculate_loan(
                    request,
                    loan_form.cleaned_data,
                    payments,
                    borrows,
                    [item_data],  # Pass only the current item, not combined with session items
                    save_to_db=False
                )
            else:
                messages.error(request, "Please fill all loan details correctly")

        # --- Handle Reset ---
        elif 'reset' in request.POST:
            request.session.pop('loan_data', None)
            request.session.pop('payments', None)
            request.session.pop('borrows', None)
            request.session.pop('items', None)
            return redirect('calculator')

        # Reinitialize forms with session data if needed
        if loan_data:
            loan_form = LoanForm(initial={
                'principal': loan_data['principal'],
                'interest_rate': loan_data['interest_rate'],
                'interest_mode': loan_data['interest_mode'],
                'start_date': loan_data['start_date'],
            })

        return render(request, self.template_name, {
            'loan_form': loan_form,
            'item_form': item_form,
            'payments': payments,
            'borrows': borrows,
            'items': items,
            'current_client': request.session.get('current_client')
        })
                
    def calculate_interest(self, principal, rate, days, mode):
        principal = Decimal(str(principal))
        rate = Decimal(str(rate))
        days = Decimal(str(days))
        
        if principal <= Decimal('0'):
            return Decimal('0')
            
        if mode == 'daily':
            return principal * ((rate / Decimal('365')) / Decimal('100')) * days
        elif mode == 'monthly':
            return principal * ((rate / Decimal('12')) / Decimal('100')) * days
        elif mode == 'yearly':
            return principal * ((rate / Decimal('1')) / Decimal('100')) * days
        return Decimal('0')

    def calculate_loan(self, request, loan_data, payment_data, borrow_data, item_data, save_to_db=True):
        # Convert to Decimal for precise calculations
        principal = Decimal(str(loan_data['principal']))
        rate = Decimal(str(loan_data['interest_rate']))
        mode = loan_data['interest_mode']
        start_date = loan_data['start_date']
        
        # Initialize additional variables
        additional_borrows = Decimal('0')
        total_interest = Decimal('0')
        
        payment_history = []

        # Create combined timeline of events
        events = []
        for p in payment_data:
            try:
                event_date = datetime.strptime(p['date'], '%Y-%m-%d').date()
                amount = Decimal(p['amount'])
                events.append(('payment', event_date, amount))
            except:
                continue
            
        for b in borrow_data:
            try:
                event_date = datetime.strptime(b['date'], '%Y-%m-%d').date()
                amount = Decimal(b['amount']).quantize(Decimal('0.01'))
                borrow_rate = Decimal(b['rate']).quantize(Decimal('0.01'))
                borrow_mode = b['mode']
                events.append(('borrow', event_date, amount, borrow_rate, borrow_mode))
                additional_borrows += amount
            except:
                continue
            
        # Sort events chronologically
        events.sort(key=lambda x: x[1])

        # Initialize tracking variables
        current_date = start_date
        current_principal = principal
        principal_groups = [{
            'principal': principal,
            'rate': rate,
            'mode': mode,
            'start_date': start_date
        }]
        
        #current_balance_without_interest = current_principal

        # Process each event in order
        for event_type, event_date, amount, event_rate, event_mode in events:
            # Calculate days since last event
            days = (event_date - current_date).days
            if days < 0:
                continue
            
            # Calculate interest for this period
            daily_interest = Decimal('0.00')
            for group in principal_groups:
                if group['principal'] > 0:
                    interest = self.calculate_interest(
                        group['principal'], group['rate'], days, group['mode']
                    )
                    daily_interest += interest
                    total_interest += interest

            if event_type == 'borrow':
                # Record borrow event with interest calculation
                principal_groups.append({
                    'principal': amount,
                    'rate': event_rate,
                    'mode': event_mode,
                    'start_date': event_date
                })
                current_principal += amount
                
                payment_history.append({
                    'date': event_date,
                    'type': 'borrow',
                    'days': days,
                    'interest': float(interest),
                    'payment': 0.0,
                    'borrow': float(amount),
                    'balance_without_interest': float(current_principal),
                    'balance_with_interest': float(current_principal + total_interest),
                    'interest_rate': float(event_rate),
                    'interest_mode': event_mode
                })

                # Add borrow amount to principal
                
            else:  # Payment event
                remaining_payment = amount
                for group in principal_groups:
                    if remaining_payment <= 0:
                        break
                    if group['principal'] > 0:
                        payment_applied = min(group['principal'], remaining_payment)
                        group['principal'] -= payment_applied
                        remaining_payment -= payment_applied
                        current_principal -= payment_applied
                        
                # Record payment event
                payment_history.append({
                    'date': event_date,
                    'type': 'payment',
                    'days': days,
                    'interest': float(interest),
                    'payment': float(amount),
                    'borrow': 0.0,
                    'balance_without_interest': float(current_principal),
                    'balance_with_interest': float(current_principal + total_interest),
                })
                        

            current_date = event_date

        # Calculate final interest from last event to today
        today = date.today()
        final_days = (today - current_date).days
        if final_days < 0:
            final_days = 0

        final_interest = Decimal('0.00')
        for group in principal_groups:
            if group['principal'] > 0:
                interest = self.calculate_interest(
                    group['principal'], group['rate'], final_days, group['mode']
                )
                final_interest += interest
                total_interest += interest
        
        current_balance_with_interest = current_principal + total_interest

        # Prepare context for results
        context = {
            'principal': float(principal),
            'total_principal': float(principal + additional_borrows),
            'rate': float(rate),
            'mode': mode,
            'start_date': start_date,
            'total_paid': float(sum(Decimal(p['amount']) for p in payment_data)),
            'total_interest': float(total_interest),
            'final_interest': float(final_interest),
            'current_balance_without_interest': float(current_principal),
            'current_balance_with_interest': float(current_balance_with_interest),
            'final_days': final_days,
            'payment_history': payment_history,
            'today': today,
            'profit': float(total_interest),
            'additional_borrows': float(additional_borrows),
            'items': item_data,  # Include items in context
        }

        # Save to database if client exists
        if save_to_db:
            client_id = request.session.get('current_client_id')
            if client_id:
                try:
                    client = Client.objects.get(id=client_id)
                    # Create Loan record
                    loan = Loan.objects.create(
                        client=client,
                        principal=principal + additional_borrows,
                        initial_principal=principal,
                        interest_rate=rate,
                        interest_mode=mode,
                        start_date=start_date,
                        total_interest=total_interest,
                        current_balance=current_balance_with_interest,
                        total_paid=float(sum(Decimal(p['amount']) for p in payment_data)),
                        profit=total_interest
                    )

                    # Create Payment and Borrow records
                    for event in payment_history:
                        if event['type'] == 'borrow':
                            Borrow.objects.create(
                                loan=loan,
                                date=event['date'],
                                amount=event['borrow'],
                                days_since_last=event['days'],
                                interest_accrued=event['interest'],
                                balance_before=event['balance_without_interest'],
                                balance_after=event['balance_without_interest'] + event['borrow']
                            )
                        else:
                            Payment.objects.create(
                                loan=loan,
                                date=event['date'],
                                amount=event['payment'],
                                days_since_last=event['days'],
                                interest_accrued=event['interest'],
                                balance_without_interest=event['balance_without_interest'],
                                balance_with_interest=event['balance_with_interest']
                            )

                    # Save items if any
                    for item in item_data:
                        if item.get('name'):
                            try:
                                last_challan = Item.objects.filter(loan=loan).order_by('-challan_number').first()
                                next_challan = last_challan.challan_number + 1 if last_challan else 1

                                Item.objects.create(
                                    loan=loan,
                                    name=item['name'],
                                    unit=item['unit'],
                                    quantity=Decimal(item['quantity']),
                                    price_per_unit=Decimal(item.get('price_per_unit', 0)),
                                    receiver_name=item.get('receiver_name', ''),
                                    challan_number=next_challan,
                                    status="Pending"
                                )
                            except Exception as e:
                                messages.error(request, f"Error saving item: {str(e)}")
                                continue
                except Exception as e:
                    messages.error(request, f"Database error: {str(e)}")

        return render(request, 'loan_app/results.html', context)

def save_logs(request):
    if request.method == 'POST':
        # Create CSV response
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="loan_logs_{}.csv"'.format(
            datetime.now().strftime("%Y%m%d_%H%M%S")
        )
        
        writer = csv.writer(response)
        
        # Write header
        writer.writerow([
            'Client Name', 'Shop Name', 'Phone', 'Address',
            'Principal', 'Interest Rate', 'Interest Mode', 'Start Date',
            'Total Paid', 'Total Interest', 'Current Balance', 'Profit'
        ])
        
        # Write data
        writer.writerow([
            request.POST.get('client_name', ''),
            request.POST.get('shop_name', ''),
            request.POST.get('phone', ''),
            request.POST.get('address', ''),
            request.POST.get('principal', ''),
            request.POST.get('rate', ''),
            request.POST.get('mode', ''),
            request.POST.get('start_date', ''),
            request.POST.get('total_paid', ''),
            request.POST.get('total_interest', ''),
            request.POST.get('current_balance', ''),
            request.POST.get('profit', ''),
        ])
        
        return response
        
def open_khata(request, client_id):
    client = get_object_or_404(Client, id=client_id)

    # Store client in session
    request.session['current_client_id'] = client.id
    request.session['current_client'] = {
        'name': client.name,
        'shop_name': client.shop_name,
        'phone': client.phone,
        'address': client.address
    }
    
    return redirect('calculator')

from django.http import JsonResponse

def debug_loans(request):
    clients = Client.objects.annotate(
        total_borrowed=Sum('loans__principal'),
        total_paid=Sum('loans__payments__amount'),
        total_interest=Sum('loans__payments__interest_accrued')
    ).values('name', 'total_borrowed', 'total_paid', 'total_interest')
    
    loans = Loan.objects.values(
        'client__name', 'principal', 'start_date', 'total_paid', 'total_interest', 'current_balance'
    )
    
    payments = Payment.objects.values(
        'loan__client__name', 'amount', 'date', 'interest_accrued'
    )

from django.views.generic import ListView, CreateView
from django.urls import reverse_lazy
from django.shortcuts import get_object_or_404, redirect
from .models import ItemLog
from .forms import ItemLogForm

class ItemLogView(CreateView, ListView):
    model = ItemLog
    form_class = ItemLogForm
    template_name = 'loan_app/item_logs.html'
    success_url = reverse_lazy('item_logs')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['logs'] = ItemLog.objects.all().order_by('-date')
        return context

def delete_item_log(request, pk):
    log = get_object_or_404(ItemLog, pk=pk)
    log.delete()
    return redirect('item_logs')

class PaymentEditView(UpdateView):
    model = Payment
    form_class = PaymentEditForm
    template_name = 'loan_app/edit_payment.html'
    
    def form_valid(self, form):
        payment = form.save(commit=False)
        payment.save()
        
        # Recalculate loan balances
        loan = payment.loan
        self.recalculate_loan_balances(loan)
        
        messages.success(self.request, "Payment updated successfully!")
        return redirect('client_detail', pk=loan.client.id)
    
    def recalculate_loan_balances(self, loan):
        # This is a simplified version - you might need a more comprehensive recalculation
        total_paid = loan.payments.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        loan.total_paid = total_paid
        loan.current_balance = loan.principal + loan.total_interest - total_paid
        loan.save()
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['client'] = self.object.loan.client
        return context

class PaymentDeleteView(DeleteView):
    model = Payment
    template_name = 'loan_app/confirm_delete.html'
    
    def delete(self, request, *args, **kwargs):
        payment = self.get_object()
        client_id = payment.loan.client.id
        payment.delete()
        
        # Recalculate loan balances
        loan = payment.loan
        self.recalculate_loan_balances(loan)
        
        messages.success(request, "Payment deleted successfully!")
        return redirect('client_detail', pk=client_id)
    
    def recalculate_loan_balances(self, loan):
        total_paid = loan.payments.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        loan.total_paid = total_paid
        loan.current_balance = loan.principal + loan.total_interest - total_paid
        loan.save()
    
    def get_success_url(self):
        return reverse('client_detail', kwargs={'pk': self.object.loan.client.id})

class BorrowEditView(UpdateView):
    model = Borrow
    form_class = BorrowEditForm
    template_name = 'loan_app/edit_borrow.html'
    
    def form_valid(self, form):
        borrow = form.save(commit=False)
        borrow.save()
        
        # Recalculate loan balances
        loan = borrow.loan
        self.recalculate_loan_balances(loan)
        
        messages.success(self.request, "Borrow updated successfully!")
        return redirect('client_detail', pk=loan.client.id)
    
    def recalculate_loan_balances(self, loan):
        total_borrowed = loan.borrows.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        loan.principal = loan.initial_principal + total_borrowed
        loan.current_balance = loan.principal + loan.total_interest - loan.total_paid
        loan.save()
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['client'] = self.object.loan.client
        return context

class BorrowDeleteView(DeleteView):
    model = Borrow
    template_name = 'loan_app/confirm_delete_borrow.html'
    
    def delete(self, request, *args, **kwargs):
        borrow = self.get_object()
        client_id = borrow.loan.client.id
        borrow.delete()
        
        # Recalculate loan balances
        loan = borrow.loan
        self.recalculate_loan_balances(loan)
        
        messages.success(request, "Borrow deleted successfully!")
        return redirect('client_detail', pk=client_id)
    
    def recalculate_loan_balances(self, loan):
        total_borrowed = loan.borrows.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        loan.principal = loan.initial_principal + total_borrowed
        loan.current_balance = loan.principal + loan.total_interest - loan.total_paid
        loan.save()
    
    def get_success_url(self):
        return reverse('client_detail', kwargs={'pk': self.object.loan.client.id})

from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import DeleteView
from django.contrib import messages
from django.urls import reverse

# Import your models
from .models import Client, Casting  

# Import your forms
from .forms import CastingForm
# Add to your views.py


class CastingDeleteView(DeleteView):
    model = Casting
    template_name = 'loan_app/casting_confirm_delete.html'
    
    def get_success_url(self):
        client_id = self.object.client.id
        messages.success(self.request, "Casting entry deleted successfully!")
        return reverse('casting_list', kwargs={'client_id': client_id})
    
    
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal
from .models import CastingKhata, CastingOrder, Client, Casting
from .forms import CastingForm, CastingKhataForm, CastingOrderForm

# ... existing imports and views ...

class CastingListView(View):
    template_name = 'loan_app/casting_list.html'
    
    def get(self, request, client_id):
        client = get_object_or_404(Client, id=client_id)
        castings = Casting.objects.filter(client=client).order_by('-created_at')
        casting_khatas = CastingKhata.objects.filter(client=client)
        form = CastingForm(client=client)
        
        # Calculate quantity information
        total_quantity = client.total_quantity()
        total_casted = client.total_casted_quantity()
        remaining_quantity = total_quantity - total_casted
        
        return render(request, self.template_name, {
            'client': client,
            'castings': castings,
            'casting_khatas': casting_khatas,
            'form': form,
            'total_quantity': total_quantity,
            'total_casted': total_casted,
            'remaining_quantity': remaining_quantity
        })
    
    def post(self, request, client_id):
        client = get_object_or_404(Client, id=client_id)
        form = CastingForm(request.POST, client=client)
        castings = Casting.objects.filter(client=client).order_by('-created_at')
        casting_khatas = CastingKhata.objects.filter(client=client)
        
        # Calculate quantity information
        total_quantity = client.total_quantity()
        total_casted = client.total_casted_quantity() 
        remaining_quantity = total_quantity - total_casted

        print(f"Form is valid: {form.is_valid()}")  # Debug print
        
        if form.is_valid():
            print("Form is valid, processing...") 
            casting = form.save(commit=False)
            casting.client = client
            
            # Check if caster already has a khata
            caster_name = form.cleaned_data['caster_name']
            casting_quantity = form.cleaned_data['quantity']

            print(f"Caster: {caster_name}, Quantity: {casting_quantity}")  # Debug print
            
            # Create or update casting khata
            khata, created = CastingKhata.objects.get_or_create(
                client=client,
                caster_name=caster_name,
                defaults={
                    'allocated_quantity': casting_quantity,
                    'available_quantity': casting_quantity
                }
            )
            
            if not created:
                khata.allocated_quantity += casting_quantity
                khata.available_quantity += casting_quantity
                khata.save()
            
            casting.save()
            messages.success(request, "Casting entry added successfully!")
            return redirect('casting_list', client_id=client_id)
        else:
            print(f"Form errors: {form.errors}")  # Debug print
            messages.error(request, f"Form validation failed: {form.errors}")
        
        return render(request, self.template_name, {
            'client': client,
            'castings': castings,
            'casting_khatas': casting_khatas,
            'form': form,
            'total_quantity': total_quantity,
            'total_casted': total_casted,
            'remaining_quantity': remaining_quantity
        })

class AddCastingQuantityView(View):
    def post(self, request, khata_id):
        khata = get_object_or_404(CastingKhata, id=khata_id)
        quantity = Decimal(request.POST.get('quantity', 0))
        
        if quantity <= 0:
            return JsonResponse({'success': False, 'error': 'Quantity must be positive'})
        
        # Get the client's remaining quantity
        client = khata.client
        client_remaining = client.remaining_quantity()
        
        # Validate that we have enough remaining quantity
        if quantity > client_remaining:
            return JsonResponse({
                'success': False, 
                'error': f'Not enough quantity available. Only {client_remaining} kg remaining'
            })
        
        # Update khata
        khata.allocated_quantity += quantity
        khata.available_quantity += quantity
        khata.save()
        
        # Create a casting record for this addition
        Casting.objects.create(
            client=client,
            item_name=f"Additional allocation for {khata.caster_name}",
            caster_name=khata.caster_name,
            unit='kg',
            narration=f"Added {quantity} kg to {khata.caster_name}'s khata",
            quantity=quantity,
            shot_charge=0
        )
        
        return JsonResponse({
            'success': True,
            'allocated_quantity': float(khata.allocated_quantity),
            'available_quantity': float(khata.available_quantity)
        })

class CreateCastingOrderView(View):
    def post(self, request, khata_id):
        khata = get_object_or_404(CastingKhata, id=khata_id)
        order_quantity = Decimal(request.POST.get('order_quantity', 0))
        
        if order_quantity <= 0:
            return JsonResponse({'success': False, 'error': 'Order quantity must be positive'})
        
        if order_quantity > khata.available_quantity:
            return JsonResponse({
                'success': False, 
                'error': f'Order quantity exceeds available quantity of {khata.available_quantity} kg'
            })
        
        # Calculate expected return
        expected_return = khata.calculate_expected_return(order_quantity)
        
        # Create order
        order = CastingOrder.objects.create(
            casting_khata=khata,
            order_quantity=order_quantity,
            expected_return=expected_return
        )
        
        # Update available quantity
        khata.available_quantity -= order_quantity
        khata.save()
        
        return JsonResponse({
            'success': True,
            'order_id': order.id,
            'order_quantity': float(order_quantity),
            'expected_return': float(expected_return),
            'available_quantity': float(khata.available_quantity)
        })

from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from .models import CastingKhata, CastingOrder, Client, Casting
from .forms import CastingForm

# ... other imports ...

@method_decorator(csrf_exempt, name='dispatch')
class GetCastingOrdersView(View):
    def get(self, request, khata_id):
        return self.handle_request(request, khata_id)
    
    def post(self, request, khata_id):
        return self.handle_request(request, khata_id)
    
    def handle_request(self, request, khata_id):
        khata = get_object_or_404(CastingKhata, id=khata_id)
        orders = CastingOrder.objects.filter(casting_khata=khata).order_by('-order_date')
        
        orders_data = []
        for order in orders:
            orders_data.append({
                'id': order.id,
                'order_quantity': float(order.order_quantity),
                'expected_return': float(order.expected_return),
                'actual_return': float(order.actual_return) if order.actual_return is not None else None,
                'balance': float(order.get_balance()),
                'order_date': order.order_date.strftime('%Y-%m-%d %H:%M'),
                'notes': order.notes or ''
            })
        
        # Calculate total balance for status
        total_balance = sum(order['balance'] for order in orders_data)
        
        return JsonResponse({
            'success': True,
            'orders': orders_data,
            'caster_name': khata.caster_name,
            'status': "Clear" if abs(total_balance) < 0.01 else f"Balance: {total_balance:.2f} kg"
        })
        
from django.db.models import F

@method_decorator(csrf_exempt, name='dispatch')
class UpdateActualReturnView(View):
    def post(self, request, order_id):
        try:
            order = get_object_or_404(CastingOrder, id=order_id)
            actual_return = Decimal(request.POST.get('actual_return', 0))
            
            # Validate actual return doesn't exceed expected return
            #if actual_return > order.expected_return:
            #   return JsonResponse({
            #      'success': False,
            #     'error': 'Actual return cannot exceed expected return'
            #})
            
            order.actual_return = actual_return
            order.save()
            
            # Recalculate status
            khata = order.casting_khata
            total_balance = khata.orders.aggregate(
                total_balance=Sum(F('expected_return') - F('actual_return'))
            )['total_balance'] or Decimal('0.00')
            
            status = "Clear" if abs(total_balance) < Decimal('0.01') else f"Balance: {total_balance:.2f} kg"
            
            return JsonResponse({
                'success': True,
                'balance': float(order.get_balance()),
                'status': status
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f'Error updating actual return: {str(e)}'
            })
        
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required

# ... other imports ...

@method_decorator(csrf_exempt, name='dispatch')
class DeleteCastingKhataView(View):
    def delete(self, request, khata_id):
        try:
            khata = get_object_or_404(CastingKhata, id=khata_id)
            caster_name = khata.caster_name
            khata.delete()
            
            return JsonResponse({
                'success': True,
                'message': f'{caster_name}\'s khata deleted successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f'Error deleting khata: {str(e)}'
            })


from django.views.generic import UpdateView
from django.urls import reverse_lazy

class CastingEditView(UpdateView):
    model = Casting
    fields = ['pieces', 'shot_charge']  # Only allow editing these two fields
    template_name = 'loan_app/casting_edit.html'
    
    def form_valid(self, form):
        messages.success(self.request, "Casting entry updated successfully!")
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse_lazy('casting_list', kwargs={'client_id': self.object.client.id})
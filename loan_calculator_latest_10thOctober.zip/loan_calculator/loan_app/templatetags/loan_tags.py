# loan_app/templatetags/loan_tags.py
from django import template
from decimal import Decimal

register = template.Library()

@register.filter
def sum_payments(payments):
    return sum(p.amount for p in payments)

@register.filter
def sub(value, arg):
    return value - arg
from django import template

register = template.Library()

@register.filter
def sub(value, arg):
    return value - arg

@register.filter
def sum_payments(payments):
    return sum(p.amount for p in payments)